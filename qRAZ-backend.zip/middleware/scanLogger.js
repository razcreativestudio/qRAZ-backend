/**
 * Scan Logger Middleware
 * Records scan events when QR codes are accessed
 */

const ScanLog = require('../models/ScanLog');
const DynamicQR = require('../models/DynamicQR');
const UAParser = require('ua-parser-js');

/**
 * Log a scan event
 * Should be called before redirect in GET /qr/:shortCode
 */
const scanLogger = async (req, res, next) => {
    try {
        const shortCode = req.params.shortCode;

        // Parse user agent
        const parser = new UAParser(req.headers['user-agent']);
        const ua = parser.getResult();

        // Determine device type
        let deviceType = 'unknown';
        if (ua.device.type === 'mobile') {
            deviceType = 'mobile';
        } else if (ua.device.type === 'tablet') {
            deviceType = 'tablet';
        } else if (ua.os.name) {
            deviceType = 'desktop';
        }

        // Get client IP (considering proxies)
        const ipAddress = req.headers['x-forwarded-for']?.split(',')[0] ||
            req.connection?.remoteAddress ||
            req.ip ||
            'unknown';

        // Create scan log entry
        await ScanLog.create({
            shortCode,
            ipAddress,
            userAgent: req.headers['user-agent']?.substring(0, 500) || 'unknown',
            deviceType,
            browser: ua.browser.name || 'unknown',
            os: ua.os.name || 'unknown',
            referer: req.headers['referer'] || null
        });

        // Increment scan counter (async, don't wait)
        DynamicQR.updateOne(
            { shortCode },
            { $inc: { totalScans: 1 } }
        ).exec();

        console.log(`📊 Scan logged: ${shortCode} from ${deviceType}`);

    } catch (error) {
        // Don't block redirect if logging fails
        console.error('⚠️ Scan logging error:', error.message);
    }

    next();
};

module.exports = scanLogger;
