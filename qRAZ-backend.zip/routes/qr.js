/**
 * QR Routes
 * Handles all QR code CRUD operations and redirects
 */

const express = require('express');
const router = express.Router();
const DynamicQR = require('../models/DynamicQR');
const ScanLog = require('../models/ScanLog');
const scanLogger = require('../middleware/scanLogger');
const { generateUniqueShortCode, isValidUrl } = require('../utils/shortCodeGenerator');

/**
 * POST /api/qr/dynamic
 * Create a new dynamic QR code
 */
router.post('/dynamic', async (req, res) => {
    try {
        const { targetUrl, title } = req.body;

        // Validate input
        if (!targetUrl) {
            return res.status(400).json({
                success: false,
                error: 'Target URL is required'
            });
        }

        // Validate URL format
        if (!isValidUrl(targetUrl)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid URL format'
            });
        }

        // Generate unique short code
        const shortCode = await generateUniqueShortCode();

        // Create QR record
        const qr = await DynamicQR.create({
            shortCode,
            targetUrl,
            title: title || null
        });

        // Build short URL
        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`;
        const shortUrl = `${baseUrl}/qr/${shortCode}`;

        console.log(`✅ Dynamic QR created: ${shortCode} -> ${targetUrl}`);

        res.status(201).json({
            success: true,
            shortCode,
            shortUrl,
            targetUrl: qr.targetUrl,
            createdAt: qr.createdAt
        });

    } catch (error) {
        console.error('❌ Create QR error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create dynamic QR'
        });
    }
});

/**
 * GET /qr/:shortCode
 * Redirect endpoint - This is what QR codes point to
 */
router.get('/:shortCode', scanLogger, async (req, res) => {
    try {
        const { shortCode } = req.params;

        // Find the QR code
        const qr = await DynamicQR.findOne({ shortCode, isActive: true });

        if (!qr) {
            return res.status(404).send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>QR Code Not Found</title>
                    <style>
                        body { font-family: 'Poppins', sans-serif; background: #121212; color: #f0f0f0; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
                        .container { text-align: center; }
                        h1 { color: #FFD700; }
                        a { color: #FFD700; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>QR Code Not Found</h1>
                        <p>This QR code is invalid or has been deactivated.</p>
                        <p><a href="https://raz.my.id">Visit RAZ Creative Studio</a></p>
                    </div>
                </body>
                </html>
            `);
        }

        // Redirect to target URL
        res.redirect(302, qr.targetUrl);

    } catch (error) {
        console.error('❌ Redirect error:', error);
        res.status(500).send('Internal Server Error');
    }
});

/**
 * PUT /api/qr/update
 * Update target URL for a dynamic QR
 */
router.put('/update', async (req, res) => {
    try {
        const { shortCode, newTargetUrl, title } = req.body;

        // Validate input
        if (!shortCode || !newTargetUrl) {
            return res.status(400).json({
                success: false,
                error: 'Short code and new target URL are required'
            });
        }

        // Validate URL format
        if (!isValidUrl(newTargetUrl)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid URL format'
            });
        }

        // Find and update
        const qr = await DynamicQR.findOneAndUpdate(
            { shortCode },
            {
                targetUrl: newTargetUrl,
                title: title !== undefined ? title : undefined,
                updatedAt: new Date()
            },
            { new: true }
        );

        if (!qr) {
            return res.status(404).json({
                success: false,
                error: 'QR code not found'
            });
        }

        console.log(`✅ QR updated: ${shortCode} -> ${newTargetUrl}`);

        res.json({
            success: true,
            shortCode: qr.shortCode,
            targetUrl: qr.targetUrl,
            updatedAt: qr.updatedAt
        });

    } catch (error) {
        console.error('❌ Update QR error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update QR'
        });
    }
});

/**
 * DELETE /api/qr/delete/:shortCode
 * Deactivate a dynamic QR (soft delete)
 */
router.delete('/delete/:shortCode', async (req, res) => {
    try {
        const { shortCode } = req.params;

        const qr = await DynamicQR.findOneAndUpdate(
            { shortCode },
            { isActive: false, updatedAt: new Date() },
            { new: true }
        );

        if (!qr) {
            return res.status(404).json({
                success: false,
                error: 'QR code not found'
            });
        }

        console.log(`🗑️ QR deactivated: ${shortCode}`);

        res.json({
            success: true,
            message: 'QR code deactivated successfully'
        });

    } catch (error) {
        console.error('❌ Delete QR error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete QR'
        });
    }
});

/**
 * GET /api/qr/info/:shortCode
 * Get QR code information
 */
router.get('/info/:shortCode', async (req, res) => {
    try {
        const { shortCode } = req.params;

        const qr = await DynamicQR.findOne({ shortCode });

        if (!qr) {
            return res.status(404).json({
                success: false,
                error: 'QR code not found'
            });
        }

        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`;

        res.json({
            success: true,
            shortCode: qr.shortCode,
            shortUrl: `${baseUrl}/qr/${qr.shortCode}`,
            targetUrl: qr.targetUrl,
            title: qr.title,
            isActive: qr.isActive,
            totalScans: qr.totalScans,
            createdAt: qr.createdAt,
            updatedAt: qr.updatedAt
        });

    } catch (error) {
        console.error('❌ Get QR info error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get QR info'
        });
    }
});

/**
 * GET /api/qr/analytics/:shortCode
 * Get detailed analytics for a QR code
 */
router.get('/analytics/:shortCode', async (req, res) => {
    try {
        const { shortCode } = req.params;

        // Get QR info
        const qr = await DynamicQR.findOne({ shortCode });

        if (!qr) {
            return res.status(404).json({
                success: false,
                error: 'QR code not found'
            });
        }

        // Get today's date at midnight
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Get date 7 days ago
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        sevenDaysAgo.setHours(0, 0, 0, 0);

        // Aggregate analytics data
        const [
            totalScans,
            uniqueScans,
            todayScans,
            scansPerDay,
            deviceBreakdown
        ] = await Promise.all([
            // Total scans
            ScanLog.countDocuments({ shortCode }),

            // Unique IPs in the last 30 days
            ScanLog.distinct('ipAddress', {
                shortCode,
                timestamp: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
            }).then(ips => ips.length),

            // Today's scans
            ScanLog.countDocuments({
                shortCode,
                timestamp: { $gte: today }
            }),

            // Scans per day (last 7 days)
            ScanLog.aggregate([
                {
                    $match: {
                        shortCode,
                        timestamp: { $gte: sevenDaysAgo }
                    }
                },
                {
                    $group: {
                        _id: {
                            $dateToString: { format: '%Y-%m-%d', date: '$timestamp' }
                        },
                        count: { $sum: 1 }
                    }
                },
                { $sort: { _id: 1 } },
                {
                    $project: {
                        _id: 0,
                        date: '$_id',
                        count: 1
                    }
                }
            ]),

            // Device breakdown
            ScanLog.aggregate([
                { $match: { shortCode } },
                {
                    $group: {
                        _id: '$deviceType',
                        count: { $sum: 1 }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        device: '$_id',
                        count: 1
                    }
                }
            ])
        ]);

        // Get recent scans (last 10)
        const recentScans = await ScanLog.find({ shortCode })
            .sort({ timestamp: -1 })
            .limit(10)
            .select('timestamp deviceType browser os -_id');

        res.json({
            success: true,
            shortCode,
            targetUrl: qr.targetUrl,
            isActive: qr.isActive,
            totalScans,
            uniqueScans,
            todayScans,
            scansPerDay,
            deviceBreakdown,
            recentScans,
            createdAt: qr.createdAt
        });

    } catch (error) {
        console.error('❌ Analytics error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get analytics'
        });
    }
});

/**
 * GET /api/qr/list
 * List all QR codes (paginated)
 */
router.get('/list', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const [qrs, total] = await Promise.all([
            DynamicQR.find({ isActive: true })
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .select('shortCode targetUrl title totalScans createdAt'),
            DynamicQR.countDocuments({ isActive: true })
        ]);

        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`;

        res.json({
            success: true,
            qrs: qrs.map(qr => ({
                ...qr.toObject(),
                shortUrl: `${baseUrl}/qr/${qr.shortCode}`
            })),
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });

    } catch (error) {
        console.error('❌ List QRs error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to list QR codes'
        });
    }
});

module.exports = router;
