/**
 * Short Code Generator Utility
 * Generates unique short codes for dynamic QR codes
 */

const { nanoid } = require('nanoid');
const DynamicQR = require('../models/DynamicQR');

/**
 * Generate a unique short code
 * @param {number} length - Length of the code (default: 7)
 * @returns {Promise<string>} - Unique short code
 */
const generateUniqueShortCode = async (length = 7) => {
    let shortCode;
    let attempts = 0;
    const maxAttempts = 10;

    // Keep generating until we find a unique code
    while (attempts < maxAttempts) {
        // Generate URL-safe short code (no special chars)
        shortCode = nanoid(length);

        // Check if it already exists
        const existing = await DynamicQR.findOne({ shortCode });

        if (!existing) {
            return shortCode;
        }

        attempts++;
    }

    // If we exhaust attempts, increase length
    return nanoid(length + 2);
};

/**
 * Validate URL format
 * @param {string} url - URL to validate
 * @returns {boolean} - Is valid URL
 */
const isValidUrl = (url) => {
    try {
        new URL(url);
        return true;
    } catch {
        return false;
    }
};

module.exports = {
    generateUniqueShortCode,
    isValidUrl
};
