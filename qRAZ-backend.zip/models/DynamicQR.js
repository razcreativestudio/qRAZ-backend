/**
 * DynamicQR Model
 * Stores dynamic QR code data (short codes and target URLs)
 */

const mongoose = require('mongoose');

const DynamicQRSchema = new mongoose.Schema({
    // Unique short code for the QR
    shortCode: {
        type: String,
        required: true,
        unique: true,
        index: true,
        maxlength: 10
    },

    // Target URL to redirect to
    targetUrl: {
        type: String,
        required: true,
        maxlength: 2048
    },

    // User identifier (for future auth implementation)
    userId: {
        type: String,
        default: 'anonymous'
    },

    // Optional title/label for the QR
    title: {
        type: String,
        maxlength: 100
    },

    // QR code status
    isActive: {
        type: Boolean,
        default: true
    },

    // Scan counter (denormalized for performance)
    totalScans: {
        type: Number,
        default: 0
    },

    // Timestamps
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Update the updatedAt timestamp on save
DynamicQRSchema.pre('save', function (next) {
    this.updatedAt = new Date();
    next();
});

// Indexes for efficient queries
DynamicQRSchema.index({ createdAt: -1 });
DynamicQRSchema.index({ userId: 1, createdAt: -1 });

module.exports = mongoose.model('DynamicQR', DynamicQRSchema);
