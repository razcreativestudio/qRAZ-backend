/**
 * ScanLog Model
 * Records each scan event for analytics
 */

const mongoose = require('mongoose');

const ScanLogSchema = new mongoose.Schema({
    // Reference to the QR code
    shortCode: {
        type: String,
        required: true,
        index: true
    },

    // Timestamp of the scan
    timestamp: {
        type: Date,
        default: Date.now,
        index: true
    },

    // Client IP address (hashed for privacy in production)
    ipAddress: {
        type: String,
        default: 'unknown'
    },

    // User agent string for device detection
    userAgent: {
        type: String,
        maxlength: 500
    },

    // Parsed device type
    deviceType: {
        type: String,
        enum: ['mobile', 'tablet', 'desktop', 'unknown'],
        default: 'unknown'
    },

    // Browser information
    browser: {
        type: String,
        maxlength: 50
    },

    // Operating system
    os: {
        type: String,
        maxlength: 50
    },

    // Referrer URL
    referer: {
        type: String,
        maxlength: 500
    },

    // Country (from IP geolocation - optional)
    country: {
        type: String,
        maxlength: 50
    }
});

// Compound indexes for analytics queries
ScanLogSchema.index({ shortCode: 1, timestamp: -1 });
ScanLogSchema.index({ shortCode: 1, ipAddress: 1, timestamp: 1 });

// TTL index to auto-delete logs after 365 days (optional, for data retention)
// ScanLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 31536000 });

module.exports = mongoose.model('ScanLog', ScanLogSchema);
